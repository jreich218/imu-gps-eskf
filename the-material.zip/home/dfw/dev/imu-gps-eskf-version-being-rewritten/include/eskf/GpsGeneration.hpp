#pragma once

#include <vector>

#include <nlohmann/json.hpp>

#include "eskf/Eskf.hpp"

namespace eskf
{

    constexpr double kDefaultGpsHz = 10.0;
    constexpr double kDefaultGpsSigmaXY = 2.0;
    constexpr unsigned int kDefaultGpsSeed = 1234;

    std::vector<GpsSample> generate_gps_samples_from_pose(
        const nlohmann::json &pose_array,
        double gps_hz = kDefaultGpsHz,
        double sigma_xy = kDefaultGpsSigmaXY,
        unsigned int seed = kDefaultGpsSeed);

} // namespace eskf
