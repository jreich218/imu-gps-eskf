#pragma once

#include <cstdint>
#include <vector>

#include <Eigen/Dense>
#include <Eigen/Geometry>

namespace eskf
{

    // G = global frame, I = IMU frame, A = gravity-aligned frame from the input IMU quaternion.

    struct ImuSample
    {
        std::int64_t utime = 0;                 // [us]
        Eigen::Vector3d linear_accel{0, 0, 0};  // specific force in I
        Eigen::Vector3d rotation_rate{0, 0, 0}; // angular velocity in I
        Eigen::Quaterniond q_AI{1, 0, 0, 0};    // I -> A
    };

    struct GpsSample
    {
        std::int64_t utime = 0;    // [us]
        Eigen::Vector2d pos{0, 0}; // (x, y) in G
    };

    struct NominalState
    {
        Eigen::Vector3d p_G{0, 0, 0};
        Eigen::Vector3d v_G{0, 0, 0};
        Eigen::Quaterniond q_GI{1, 0, 0, 0}; // I -> G
    };

    struct UpdateDebug
    {
        Eigen::Vector2d innovation_xy{0, 0};
        double nis = 0.0;
    };

    class Eskf
    {
    public:
        using Covariance = Eigen::Matrix<double, 9, 9>;

        Eskf();

        void initialize_from_estimate(
            const Eigen::Vector2d &position_xy,
            const Eigen::Vector2d &velocity_xy,
            double yaw_rad,
            const ImuSample &imu_ref);

        // Predict with one IMU sample.
        void predict(const ImuSample &imu_k);

        // Update with one GPS sample.
        UpdateDebug update_gps(const GpsSample &gps_k);

        const NominalState &state() const;
        const Covariance &covariance() const;

    private:
        static Eigen::Matrix3d skew(const Eigen::Vector3d &v);
        static Eigen::Quaterniond quat_from_yaw(double yaw_rad);
        static Eigen::Quaterniond delta_quat_from_rotvec(const Eigen::Vector3d &dtheta);
        static void symmetrize_and_clamp(Covariance &P);

        bool initialized_ = false;
        std::int64_t last_imu_utime_ = 0;

        NominalState state_{};
        Covariance P_{Covariance::Zero()};
    };

} // namespace eskf
