#pragma once

#include <cstdint>
#include <filesystem>
#include <string>
#include <unordered_map>
#include <vector>

#include <Eigen/Dense>
#include <nlohmann/json.hpp>

#include "eskf/Eskf.hpp"

namespace eskf
{

    using PoseTruthMap = std::unordered_map<std::int64_t, Eigen::Vector2d>;

    struct SceneData
    {
        nlohmann::json pose_json;
        std::vector<ImuSample> imu_samples;
        PoseTruthMap pose_truth;
    };

    struct SceneInputs
    {
        std::string label;
        std::filesystem::path pose_path;
        std::filesystem::path imu_path;
    };

    std::filesystem::path resolve_repo_path(const std::filesystem::path &relative_path);
    SceneInputs select_scene_inputs(const std::filesystem::path &scenarios_dir);
    SceneData load_scene_data(const std::filesystem::path &pose_path, const std::filesystem::path &imu_path);

} // namespace eskf
