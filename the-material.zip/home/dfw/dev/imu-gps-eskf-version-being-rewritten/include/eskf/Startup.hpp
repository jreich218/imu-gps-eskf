#pragma once

#include <optional>
#include <vector>

#include <Eigen/Dense>

#include "eskf/Eskf.hpp"

namespace eskf
{

    struct StartupInitialization
    {
        Eigen::Vector2d position_xy{0.0, 0.0};
        Eigen::Vector2d velocity_xy{0.0, 0.0};
        double yaw_rad = 0.0;
        std::size_t handoff_imu_index = 0;
        std::size_t next_gps_index = 0;
    };

    std::optional<StartupInitialization> compute_startup_initialization(
        const std::vector<ImuSample> &imu_samples,
        const std::vector<GpsSample> &gps_samples);

} // namespace eskf
