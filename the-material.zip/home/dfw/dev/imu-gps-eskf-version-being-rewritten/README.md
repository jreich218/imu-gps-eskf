# IMU-GPS-ESKF

This repository is a C++/Eigen IMU+GPS Error-State Kalman Filter baseline for ego-state estimation.

## nuScenes pose timestamps at scene end

Across the 979 matched `scene-XXXX_pose.json` / `scene-XXXX_ms_imu.json` pairs in
`/data/sets/nuscenes/can_bus`, 110 scenes have one final pose entry with
`utime > imu_last`. The largest gap between the final pose timestamp and the final
IMU timestamp is `31,368 us` (`31.368 ms`).

nuScenes pose is derived localization output rather than the raw IMU timebase.
This repo drops a final pose entry during scene load when it is the only pose
entry after the last IMU timestamp. Cases with two or more pose entries after
the last IMU timestamp are left unchanged.

## What is in this repo

- A C++ ESKF with startup initialization, IMU prediction, and 2D GPS updates.
- In-process GPS generation from pose data.
- A bundled pose/IMU pair so the app runs out of the box.
- Unit tests and an end-to-end integration test.

The bundled files are:

- `scenarios/scene_pose.json`
- `scenarios/scene_ms_imu.json`

They follow the same JSON shape as the nuScenes pose and IMU files this app reads. They are simulated files included so the app has a ready-to-run input pair.

## The pose file is reference truth

`scene_pose.json` is not pose estimated by this app.

It is reference trajectory data used for truth lookup, scoring, and logging. In a nuScenes run that role is played by nuScenes pose data; in the bundled run that role is played by the simulated file included here.

## Development

Run these from the repo root.

Install the C++ dependencies:

```bash
sudo apt-get update
sudo apt-get install -y g++ cmake libeigen3-dev nlohmann-json3-dev
```

Build and run with CMake:

```bash
cmake -S . -B build -DBUILD_TESTING=OFF
cmake --build build --parallel
./build/bin/eskf_sim
```

Build and run the tests:

```bash
sudo apt-get install -y libgtest-dev
cmake -S . -B build -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

Create `docs/xy_trajectory.png` after a run:

```bash
sudo apt-get install -y python3 python3-venv
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/plot_xy.py
```

Each app run writes `eskf_sim_log.csv` in the repo root.

## Input selection

The app looks in `scenarios/`.

Bundled files:

- `scene_pose.json`
- `scene_ms_imu.json`

Recognized nuScenes filenames:

- `scene-XXXX_pose.json`
- `scene-XXXX_ms_imu.json`

Selection rules:

- If there is exactly one valid nuScenes pair, the app uses it.
- Otherwise, if the bundled pair exists, the app uses the bundled pair.
- Anything else is treated as an error.

So if both the bundled pair and exactly one valid nuScenes pair are present, the nuScenes pair wins.

## GPS generation

GPS is generated fresh in C++ from the selected pose file during each run. The generator:

- downsamples pose by timestamp gating to 10 Hz,
- adds independent Gaussian noise in `x` and `y` with `sigma = 2 m`,
- keeps the first pose timestamp,
- and uses the selected pose file as the truth source for timestamp-aligned GPS samples.

The pose stream is expected to satisfy the same planar/yaw-only assumptions used elsewhere in this project:

- `pos[2]` near zero,
- quaternion form `[w, 0, 0, z]`,
- velocity form `[v, 0, 0]`,
- strictly increasing `utime`.

## Notes

- The app binary does not estimate the reference pose file. It estimates its own internal state and compares against the reference pose data.
- The same C++ GPS-generation logic is used by the app and by the integration test.
- The `g++` paths build the main app only. The CMake paths build the tests too.
- `BUILD_TESTING=OFF` skips the test build when you only want the app.
- This repo does not bundle downloaded nuScenes data.
- The integration test uses the bundled pose/IMU files and generates GPS fresh during the test run.

## References

1. nuScenes paper  
   <https://arxiv.org/abs/1903.11027>
2. nuScenes CAN bus README  
   <https://github.com/nutonomy/nuscenes-devkit/blob/master/python-sdk/nuscenes/can_bus/README.md>
3. nuScenes schema docs  
   <https://github.com/nutonomy/nuscenes-devkit/blob/master/docs/schema_nuscenes.md>
