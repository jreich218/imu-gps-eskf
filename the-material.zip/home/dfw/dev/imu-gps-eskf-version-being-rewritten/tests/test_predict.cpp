#include <gtest/gtest.h>

#include <cstdint>
#include <cmath>
#include <vector>

#include <Eigen/Dense>

#include "eskf/Eskf.hpp"

namespace
{

    eskf::Eskf make_initialized_filter(
        const Eigen::Vector2d &position_xy,
        const Eigen::Vector2d &velocity_xy,
        double yaw_rad,
        std::int64_t utime = 0)
    {
        eskf::ImuSample imu0;
        imu0.utime = utime;
        imu0.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);

        eskf::Eskf filter;
        filter.initialize_from_estimate(position_xy, velocity_xy, yaw_rad, imu0);
        return filter;
    }

    static double yaw_from_quat(const Eigen::Quaterniond &q_GI)
    {
        const double w = q_GI.w();
        const double x = q_GI.x();
        const double y = q_GI.y();
        const double z = q_GI.z();
        const double siny_cosp = 2.0 * (w * z + x * y);
        const double cosy_cosp = 1.0 - 2.0 * (y * y + z * z);
        return std::atan2(siny_cosp, cosy_cosp);
    }

    TEST(EskfPredict, GravityAlignedImuDoesNotDriftAtRest)
    {
        constexpr double g = 9.8;

        eskf::Eskf filter =
            make_initialized_filter(Eigen::Vector2d(0.0, 0.0), Eigen::Vector2d(0.0, 0.0), 0.0);

        const Eigen::Vector3d p0 = filter.state().p_G;
        const Eigen::Vector3d v0 = filter.state().v_G;

        constexpr std::int64_t dt_us = 10000;
        constexpr int N = 200;

        for (int k = 1; k <= N; ++k)
        {
            eskf::ImuSample imu;
            imu.utime = static_cast<std::int64_t>(k) * dt_us;
            imu.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
            imu.rotation_rate = Eigen::Vector3d::Zero();
            imu.linear_accel = Eigen::Vector3d(0.0, 0.0, g);

            filter.predict(imu);
        }

        const auto &st = filter.state();
        EXPECT_NEAR((st.p_G - p0).norm(), 0.0, 1e-9);
        EXPECT_NEAR((st.v_G - v0).norm(), 0.0, 1e-9);
    }

    TEST(EskfPredict, ZeroGyroKeepsAttitudeConstantAndCovarianceFiniteSymmetric)
    {
        constexpr double g = 9.8;

        eskf::Eskf filter =
            make_initialized_filter(Eigen::Vector2d(0.0, 0.0), Eigen::Vector2d(0.0, 0.0), 0.0);

        const Eigen::Quaterniond q0 = filter.state().q_GI;

        constexpr std::int64_t dt_us = 10000;
        constexpr int N = 100;

        for (int k = 1; k <= N; ++k)
        {
            eskf::ImuSample imu;
            imu.utime = static_cast<std::int64_t>(k) * dt_us;
            imu.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
            imu.rotation_rate = Eigen::Vector3d::Zero();
            imu.linear_accel = Eigen::Vector3d(0.0, 0.0, g);

            filter.predict(imu);
        }

        const auto &st = filter.state();

        EXPECT_NEAR(st.q_GI.norm(), 1.0, 1e-12);
        const double dot = std::abs(q0.dot(st.q_GI));
        EXPECT_NEAR(dot, 1.0, 1e-9);

        const auto &P = filter.covariance();
        EXPECT_TRUE(P.array().isFinite().all());
        EXPECT_LE((P - P.transpose()).norm(), 1e-10);
    }

    TEST(EskfPredict, ConstantYawRateIntegratesYawApproximately)
    {
        constexpr double g = 9.8;
        constexpr double wz = 0.1;

        eskf::Eskf filter =
            make_initialized_filter(Eigen::Vector2d(0.0, 0.0), Eigen::Vector2d(0.0, 0.0), 0.0);

        constexpr std::int64_t dt_us = 10000;
        constexpr int N = 100;
        const double dt = static_cast<double>(dt_us) * 1e-6;
        const double T = N * dt;
        const double expected_yaw = wz * T;

        for (int k = 1; k <= N; ++k)
        {
            eskf::ImuSample imu;
            imu.utime = static_cast<std::int64_t>(k) * dt_us;
            imu.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
            imu.rotation_rate = Eigen::Vector3d(0.0, 0.0, wz);
            imu.linear_accel = Eigen::Vector3d(0.0, 0.0, g); // net accel ~0

            filter.predict(imu);
        }

        const auto &st = filter.state();
        EXPECT_NEAR(st.q_GI.norm(), 1.0, 1e-12);

        const double yaw = yaw_from_quat(st.q_GI);
        EXPECT_NEAR(yaw, expected_yaw, 1e-3);

        const auto &P = filter.covariance();
        EXPECT_TRUE(P.array().isFinite().all());
        EXPECT_LE((P - P.transpose()).norm(), 1e-10);
    }

} // namespace
