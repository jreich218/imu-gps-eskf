#include <gtest/gtest.h>

#include <cstdint>
#include <cmath>
#include <vector>

#include <Eigen/Dense>

#include "eskf/Eskf.hpp"

namespace
{

    TEST(EskfUpdateGps, InnovationAndNisMatchResidualAndMovePositionTowardMeasurement)
    {
        eskf::Eskf filter;
        eskf::ImuSample imu0;
        imu0.utime = 0;
        imu0.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
        filter.initialize_from_estimate(
            Eigen::Vector2d(0.0, 0.0),
            Eigen::Vector2d(0.0, 0.0),
            0.0,
            imu0);

        const Eigen::Vector3d p_before = filter.state().p_G;
        const auto P_before = filter.covariance();

        eskf::GpsSample meas;
        meas.utime = 123456;
        meas.pos = Eigen::Vector2d(10.0, -5.0);

        const eskf::UpdateDebug dbg = filter.update_gps(meas);

        EXPECT_NEAR(dbg.innovation_xy.x(), meas.pos.x() - p_before.x(), 1e-12);
        EXPECT_NEAR(dbg.innovation_xy.y(), meas.pos.y() - p_before.y(), 1e-12);

        EXPECT_TRUE(std::isfinite(dbg.nis));
        EXPECT_GE(dbg.nis, 0.0);
        EXPECT_GT(dbg.nis, 0.0);

        const Eigen::Vector3d p_after = filter.state().p_G;

        EXPECT_GT(p_after.x(), p_before.x());
        EXPECT_LE(p_after.x(), meas.pos.x());

        EXPECT_LT(p_after.y(), p_before.y());
        EXPECT_GE(p_after.y(), meas.pos.y());

        const auto &P_after = filter.covariance();
        EXPECT_TRUE(P_after.array().isFinite().all());
        EXPECT_LE((P_after - P_after.transpose()).norm(), 1e-10);

        EXPECT_NEAR(filter.state().q_GI.norm(), 1.0, 1e-12);

        EXPECT_LT(P_after(0, 0), P_before(0, 0));
        EXPECT_LT(P_after(1, 1), P_before(1, 1));
    }

} // namespace
