#include <gtest/gtest.h>

#include <cmath>

#include <Eigen/Dense>
#include <Eigen/Geometry>

#include "eskf/Eskf.hpp"

namespace
{

    double yaw_from_quat(const Eigen::Quaterniond &q_GI)
    {
        const double w = q_GI.w();
        const double x = q_GI.x();
        const double y = q_GI.y();
        const double z = q_GI.z();
        const double siny_cosp = 2.0 * (w * z + x * y);
        const double cosy_cosp = 1.0 - 2.0 * (y * y + z * z);
        return std::atan2(siny_cosp, cosy_cosp);
    }

    TEST(EskfInitializeFromEstimate, SetsPositionVelocityAndYaw)
    {
        eskf::ImuSample imu0;
        imu0.utime = 123456;
        imu0.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);

        eskf::Eskf filter;
        filter.initialize_from_estimate(
            Eigen::Vector2d(1.0, -2.0),
            Eigen::Vector2d(3.0, 4.0),
            0.5,
            imu0);

        const auto &st = filter.state();
        EXPECT_NEAR(st.p_G.x(), 1.0, 1e-12);
        EXPECT_NEAR(st.p_G.y(), -2.0, 1e-12);
        EXPECT_NEAR(st.v_G.x(), 3.0, 1e-12);
        EXPECT_NEAR(st.v_G.y(), 4.0, 1e-12);
        EXPECT_NEAR(yaw_from_quat(st.q_GI), 0.5, 1e-12);
    }

    TEST(EskfInitializeFromEstimate, UsesImuReferenceQuaternionToInterpretYaw)
    {
        eskf::ImuSample imu0;
        imu0.utime = 0;
        const double imu_yaw = 0.3;
        imu0.q_AI = Eigen::AngleAxisd(imu_yaw, Eigen::Vector3d::UnitZ());

        eskf::Eskf filter;
        filter.initialize_from_estimate(
            Eigen::Vector2d(0.0, 0.0),
            Eigen::Vector2d(0.0, 0.0),
            1.0,
            imu0);

        const auto &st = filter.state();
        EXPECT_NEAR(yaw_from_quat(st.q_GI), 1.0, 1e-12);
    }

} // namespace
