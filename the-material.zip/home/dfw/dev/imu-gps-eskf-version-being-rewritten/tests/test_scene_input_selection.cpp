#include <gtest/gtest.h>

#include <chrono>
#include <filesystem>
#include <stdexcept>
#include <string>

#include "eskf/SceneData.hpp"

namespace fs = std::filesystem;

namespace
{

    class TempDir
    {
    public:
        TempDir()
        {
            static std::uint64_t counter = 0;
            const auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
            path_ = fs::temp_directory_path() /
                    ("eskf-scene-select-" + std::to_string(stamp) + "-" + std::to_string(counter++));
            fs::create_directories(path_);
        }

        ~TempDir()
        {
            std::error_code ec;
            fs::remove_all(path_, ec);
        }

        const fs::path &path() const
        {
            return path_;
        }

    private:
        fs::path path_;
    };

    fs::path bundled_pose_path()
    {
        return eskf::resolve_repo_path("scenarios/scene_pose.json");
    }

    fs::path bundled_imu_path()
    {
        return eskf::resolve_repo_path("scenarios/scene_ms_imu.json");
    }

    void copy_fixture_file(const fs::path &from, const fs::path &to)
    {
        fs::copy_file(from, to, fs::copy_options::overwrite_existing);
    }

} // namespace

TEST(SceneInputSelection, UsesBundledPairWhenItIsTheOnlyChoice)
{
    TempDir temp_dir;
    const fs::path scenarios_dir = temp_dir.path() / "scenarios";
    fs::create_directories(scenarios_dir);

    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene_ms_imu.json");

    const eskf::SceneInputs inputs = eskf::select_scene_inputs(scenarios_dir);

    EXPECT_EQ(inputs.label, "bundled scene");
    EXPECT_EQ(inputs.pose_path.filename().string(), "scene_pose.json");
    EXPECT_EQ(inputs.imu_path.filename().string(), "scene_ms_imu.json");
}

TEST(SceneInputSelection, PrefersSingleMatchingNuScenesPairOverBundledFiles)
{
    TempDir temp_dir;
    const fs::path scenarios_dir = temp_dir.path() / "scenarios";
    fs::create_directories(scenarios_dir);

    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene_ms_imu.json");
    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene-0364_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene-0364_ms_imu.json");

    const eskf::SceneInputs inputs = eskf::select_scene_inputs(scenarios_dir);

    EXPECT_EQ(inputs.label, "nuScenes scene-0364");
    EXPECT_EQ(inputs.pose_path.filename().string(), "scene-0364_pose.json");
    EXPECT_EQ(inputs.imu_path.filename().string(), "scene-0364_ms_imu.json");
}

TEST(SceneInputSelection, RejectsIncompleteBundledPair)
{
    TempDir temp_dir;
    const fs::path scenarios_dir = temp_dir.path() / "scenarios";
    fs::create_directories(scenarios_dir);

    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene_pose.json");

    EXPECT_THROW(eskf::select_scene_inputs(scenarios_dir), std::runtime_error);
}

TEST(SceneInputSelection, RejectsMismatchedNuScenesSceneNumbers)
{
    TempDir temp_dir;
    const fs::path scenarios_dir = temp_dir.path() / "scenarios";
    fs::create_directories(scenarios_dir);

    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene-0364_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene-0421_ms_imu.json");

    EXPECT_THROW(eskf::select_scene_inputs(scenarios_dir), std::runtime_error);
}

TEST(SceneInputSelection, RejectsMultipleNuScenesPairs)
{
    TempDir temp_dir;
    const fs::path scenarios_dir = temp_dir.path() / "scenarios";
    fs::create_directories(scenarios_dir);

    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene-0364_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene-0364_ms_imu.json");
    copy_fixture_file(bundled_pose_path(), scenarios_dir / "scene-0421_pose.json");
    copy_fixture_file(bundled_imu_path(), scenarios_dir / "scene-0421_ms_imu.json");

    EXPECT_THROW(eskf::select_scene_inputs(scenarios_dir), std::runtime_error);
}
