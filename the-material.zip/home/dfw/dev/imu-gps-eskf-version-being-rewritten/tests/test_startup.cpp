#include <gtest/gtest.h>

#include <cmath>
#include <cstdint>
#include <vector>

#include <Eigen/Dense>
#include <Eigen/Geometry>

#include "eskf/Startup.hpp"

namespace
{

    eskf::ImuSample make_imu(std::int64_t utime, double yaw_rate_z)
    {
        eskf::ImuSample imu;
        imu.utime = utime;
        imu.rotation_rate = Eigen::Vector3d(0.0, 0.0, yaw_rate_z);
        imu.q_AI = Eigen::Quaterniond(1.0, 0.0, 0.0, 0.0);
        return imu;
    }

    eskf::GpsSample make_gps(std::int64_t utime, double x, double y)
    {
        eskf::GpsSample gps;
        gps.utime = utime;
        gps.pos = Eigen::Vector2d(x, y);
        return gps;
    }

    Eigen::Vector2d circle_arc_xy(double radius_m, double heading_rad)
    {
        return Eigen::Vector2d(
            radius_m * std::sin(heading_rad),
            radius_m * (1.0 - std::cos(heading_rad)));
    }

} // namespace

TEST(StartupInitialization, IgnoresGpsBeforeFirstImuAndReadiesOnStableHeading)
{
    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, 0.0),
        make_imu(200000, 0.0),
        make_imu(300000, 0.0),
        make_imu(400000, 0.0),
        make_imu(500000, 0.0),
        make_imu(600000, 0.0),
    };

    const std::vector<eskf::GpsSample> gps_samples = {
        make_gps(0, -1.0, 0.0),
        make_gps(100000, 0.0, 0.0),
        make_gps(200000, 3.0, 0.0),
        make_gps(300000, 6.0, 0.0),
        make_gps(400000, 9.0, 0.0),
        make_gps(500000, 12.0, 0.0),
        make_gps(600000, 15.0, 0.0),
    };

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    ASSERT_TRUE(startup.has_value());
    EXPECT_EQ(startup->handoff_imu_index, 4U);
    EXPECT_EQ(startup->next_gps_index, 6U);
    EXPECT_NEAR(startup->position_xy.x(), 12.0, 1e-9);
    EXPECT_NEAR(startup->position_xy.y(), 0.0, 1e-9);
    EXPECT_NEAR(startup->velocity_xy.x(), 30.0, 1e-9);
    EXPECT_NEAR(startup->velocity_xy.y(), 0.0, 1e-9);
    EXPECT_NEAR(startup->yaw_rad, 0.0, 1e-9);
}

TEST(StartupInitialization, CarriesTheReadyStateToTheFirstLaterImuSample)
{
    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, 0.0),
        make_imu(200000, 0.0),
        make_imu(300000, 0.0),
        make_imu(400000, 0.0),
        make_imu(520000, 0.5),
        make_imu(620000, 0.5),
    };

    const std::vector<eskf::GpsSample> gps_samples = {
        make_gps(100000, 0.0, 0.0),
        make_gps(200000, 3.0, 0.0),
        make_gps(300000, 6.0, 0.0),
        make_gps(400000, 9.0, 0.0),
        make_gps(500000, 12.0, 0.0),
        make_gps(600000, 15.0, 0.0),
    };

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    ASSERT_TRUE(startup.has_value());
    EXPECT_EQ(startup->handoff_imu_index, 4U);
    EXPECT_EQ(startup->next_gps_index, 5U);
    EXPECT_NEAR(startup->position_xy.x(), 12.6, 1e-9);
    EXPECT_NEAR(startup->position_xy.y(), 0.0, 1e-9);
    EXPECT_NEAR(startup->velocity_xy.x(), 30.0, 1e-9);
    EXPECT_NEAR(startup->velocity_xy.y(), 0.0, 1e-9);
    EXPECT_NEAR(startup->yaw_rad, 0.01, 1e-9);
}

TEST(StartupInitialization, ReturnsNulloptWhenProjectedSeparationStaysBelowTheRequiredThreshold)
{
    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, 0.0),
        make_imu(200000, 0.0),
        make_imu(300000, 0.0),
        make_imu(400000, 0.0),
        make_imu(500000, 0.0),
        make_imu(600000, 0.0),
        make_imu(700000, 0.0),
    };

    const std::vector<eskf::GpsSample> gps_samples = {
        make_gps(100000, 0.0, 0.0),
        make_gps(200000, 1.0, 0.0),
        make_gps(300000, 2.0, 0.0),
        make_gps(400000, 3.0, 0.0),
        make_gps(500000, 4.0, 0.0),
        make_gps(600000, 5.0, 0.0),
        make_gps(700000, 6.0, 0.0),
    };

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    EXPECT_FALSE(startup.has_value());
}

TEST(StartupInitialization, RelaxesProjectedSeparationAfterEightyGpsPoints)
{
    std::vector<eskf::ImuSample> imu_samples;
    std::vector<eskf::GpsSample> gps_samples;
    imu_samples.reserve(80);
    gps_samples.reserve(80);

    for (std::size_t idx = 0; idx < 80; ++idx)
    {
        const std::int64_t utime =
            100000 + static_cast<std::int64_t>(idx) * 100000;
        imu_samples.push_back(make_imu(utime, 0.0));
        gps_samples.push_back(make_gps(utime, 0.1 * static_cast<double>(idx), 0.0));
    }

    const auto startup_before_eighty =
        eskf::compute_startup_initialization(
            imu_samples,
            std::vector<eskf::GpsSample>(gps_samples.begin(), gps_samples.end() - 1));

    EXPECT_FALSE(startup_before_eighty.has_value());

    const auto startup_at_eighty =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    ASSERT_TRUE(startup_at_eighty.has_value());
    EXPECT_EQ(startup_at_eighty->handoff_imu_index, 79U);
    EXPECT_EQ(startup_at_eighty->next_gps_index, 80U);
    EXPECT_NEAR(startup_at_eighty->position_xy.x(), 7.9, 1e-9);
    EXPECT_NEAR(startup_at_eighty->position_xy.y(), 0.0, 1e-9);
    EXPECT_NEAR(startup_at_eighty->velocity_xy.norm(), 1.0, 1e-6);
    EXPECT_NEAR(startup_at_eighty->yaw_rad, 0.0, 1e-9);
}

TEST(StartupInitialization, ReturnsNulloptWhenStartupNeverLooksTrustworthy)
{
    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, 0.0),
        make_imu(200000, 0.0),
        make_imu(300000, 0.0),
        make_imu(400000, 0.0),
        make_imu(500000, 0.0),
        make_imu(600000, 0.0),
        make_imu(700000, 0.0),
    };

    const std::vector<eskf::GpsSample> gps_samples = {
        make_gps(100000, 0.0, 0.0),
        make_gps(200000, 1.0, 0.0),
        make_gps(300000, 2.0, 2.0),
        make_gps(400000, 3.0, -2.0),
        make_gps(500000, 4.0, 2.0),
        make_gps(600000, 5.0, -2.0),
        make_gps(700000, 6.0, 2.0),
    };

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    EXPECT_FALSE(startup.has_value());
}

TEST(StartupInitialization, UsesPrincipalDirectionWhenLineLikeHeadingIsStillWobbling)
{
    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, 0.0),
        make_imu(200000, 0.0),
        make_imu(300000, 0.0),
        make_imu(400000, 0.0),
        make_imu(500000, 0.0),
        make_imu(600000, 0.0),
        make_imu(700000, 0.0),
    };

    const std::vector<eskf::GpsSample> gps_samples = {
        make_gps(100000, 0.0, 0.0),
        make_gps(200000, 3.0, 1.8),
        make_gps(300000, 6.0, -1.8),
        make_gps(400000, 9.0, 1.8),
        make_gps(500000, 12.0, -1.8),
        make_gps(600000, 15.0, 1.8),
        make_gps(700000, 18.0, -1.8),
    };

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    ASSERT_TRUE(startup.has_value());
    EXPECT_EQ(startup->handoff_imu_index, 4U);
    EXPECT_EQ(startup->next_gps_index, 5U);
    EXPECT_NEAR(startup->yaw_rad, 0.0, 0.15);
    EXPECT_NEAR(startup->velocity_xy.norm(), 30.2152, 0.05);
}

TEST(StartupInitialization, UsesCurvatureAwareGlobalYawWhenTheCloudIsNotLineLike)
{
    constexpr double kRadiusM = 12.0;
    constexpr double kHeadingStepRad = 1.0 / 6.0;
    const double yaw_rate_z = kHeadingStepRad / 0.1;

    const std::vector<eskf::ImuSample> imu_samples = {
        make_imu(100000, yaw_rate_z),
        make_imu(200000, yaw_rate_z),
        make_imu(300000, yaw_rate_z),
        make_imu(400000, yaw_rate_z),
        make_imu(500000, yaw_rate_z),
        make_imu(600000, yaw_rate_z),
        make_imu(700000, yaw_rate_z),
    };

    std::vector<eskf::GpsSample> gps_samples;
    gps_samples.reserve(7);
    for (std::size_t idx = 0; idx < 7; ++idx)
    {
        const double heading_rad = static_cast<double>(idx) * kHeadingStepRad;
        Eigen::Vector2d xy = circle_arc_xy(kRadiusM, heading_rad);
        if (idx == 5)
        {
            xy += Eigen::Vector2d(0.0, 2.0);
        }
        else if (idx == 6)
        {
            xy += Eigen::Vector2d(0.0, -2.0);
        }
        gps_samples.push_back(make_gps(
            100000 + static_cast<std::int64_t>(idx) * 100000,
            xy.x(),
            xy.y()));
    }

    const auto startup =
        eskf::compute_startup_initialization(imu_samples, gps_samples);

    ASSERT_TRUE(startup.has_value());
    EXPECT_EQ(startup->handoff_imu_index, 5U);
    EXPECT_EQ(startup->next_gps_index, 6U);
    EXPECT_NEAR(startup->yaw_rad, 0.56, 0.12);
    EXPECT_NEAR(startup->velocity_xy.norm(), 20.8517, 0.1);
}
