#include <gtest/gtest.h>

#include <cmath>
#include <cstdint>
#include <fstream>
#include <unordered_map>
#include <vector>

#include <nlohmann/json.hpp>

#include "eskf/GpsGeneration.hpp"
#include "eskf/SceneData.hpp"

using json = nlohmann::json;

namespace
{

    json make_pose_entry(std::int64_t utime, double x, double y)
    {
        return json{
            {"utime", utime},
            {"pos", {x, y, 0.0}},
            {"orientation", {1.0, 0.0, 0.0, 0.0}},
            {"vel", {1.0, 0.0, 0.0}},
        };
    }

    json load_json_file(const std::filesystem::path &path)
    {
        std::ifstream in(path);
        if (!in)
        {
            throw std::runtime_error("Failed to open JSON file: " + path.string());
        }

        json data;
        in >> data;
        return data;
    }

} // namespace

TEST(GpsGeneration, KeepsFirstAndThenTimestampGatedPoseSamples)
{
    const json pose = json::array({
        make_pose_entry(0, 0.0, 0.0),
        make_pose_entry(50000, 1.0, 10.0),
        make_pose_entry(100000, 2.0, 20.0),
        make_pose_entry(180000, 3.0, 30.0),
        make_pose_entry(210000, 4.0, 40.0),
    });

    const std::vector<eskf::GpsSample> gps =
        eskf::generate_gps_samples_from_pose(pose, 10.0, 0.0, 1234);

    ASSERT_EQ(gps.size(), 3U);

    EXPECT_EQ(gps[0].utime, 0);
    EXPECT_EQ(gps[1].utime, 100000);
    EXPECT_EQ(gps[2].utime, 210000);

    EXPECT_DOUBLE_EQ(gps[0].pos.x(), 0.0);
    EXPECT_DOUBLE_EQ(gps[0].pos.y(), 0.0);
    EXPECT_DOUBLE_EQ(gps[1].pos.x(), 2.0);
    EXPECT_DOUBLE_EQ(gps[1].pos.y(), 20.0);
    EXPECT_DOUBLE_EQ(gps[2].pos.x(), 4.0);
    EXPECT_DOUBLE_EQ(gps[2].pos.y(), 40.0);
}

TEST(GpsGeneration, ScenePoseProducesDeterministicTimestampAlignedSamples)
{
    const auto pose_path = eskf::resolve_repo_path("scenarios/scene_pose.json");
    const json pose = load_json_file(pose_path);

    const std::vector<eskf::GpsSample> gps =
        eskf::generate_gps_samples_from_pose(pose);
    const std::vector<eskf::GpsSample> gps_again =
        eskf::generate_gps_samples_from_pose(pose);

    ASSERT_FALSE(gps.empty());
    ASSERT_EQ(gps.size(), gps_again.size());

    std::unordered_map<std::int64_t, std::pair<double, double>> truth_xy_by_utime;
    truth_xy_by_utime.reserve(pose.size());
    std::vector<std::int64_t> expected_utimes;
    expected_utimes.reserve(pose.size());

    const auto desired_dt_us =
        static_cast<std::int64_t>(std::llround(1e6 / eskf::kDefaultGpsHz));

    bool first_kept = false;
    std::int64_t last_kept_utime = 0;

    for (const auto &entry : pose)
    {
        const std::int64_t utime = entry.at("utime").get<std::int64_t>();
        const auto &pos = entry.at("pos");
        truth_xy_by_utime.emplace(
            utime,
            std::make_pair(pos.at(0).get<double>(), pos.at(1).get<double>()));

        if (!first_kept)
        {
            first_kept = true;
            last_kept_utime = utime;
            expected_utimes.push_back(utime);
        }
        else if (utime - last_kept_utime >= desired_dt_us)
        {
            last_kept_utime = utime;
            expected_utimes.push_back(utime);
        }
    }

    ASSERT_EQ(gps.size(), expected_utimes.size());

    bool saw_noise = false;
    for (std::size_t i = 0; i < gps.size(); ++i)
    {
        EXPECT_EQ(gps[i].utime, expected_utimes[i]);
        EXPECT_EQ(gps_again[i].utime, expected_utimes[i]);
        EXPECT_DOUBLE_EQ(gps[i].pos.x(), gps_again[i].pos.x());
        EXPECT_DOUBLE_EQ(gps[i].pos.y(), gps_again[i].pos.y());
        EXPECT_TRUE(std::isfinite(gps[i].pos.x()));
        EXPECT_TRUE(std::isfinite(gps[i].pos.y()));

        const auto truth_it = truth_xy_by_utime.find(gps[i].utime);
        ASSERT_NE(truth_it, truth_xy_by_utime.end());

        if (gps[i].pos.x() != truth_it->second.first || gps[i].pos.y() != truth_it->second.second)
        {
            saw_noise = true;
        }
    }

    EXPECT_TRUE(saw_noise);
}
