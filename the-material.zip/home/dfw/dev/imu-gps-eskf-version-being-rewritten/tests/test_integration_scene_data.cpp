#include <gtest/gtest.h>

#include <cmath>
#include <chrono>
#include <filesystem>
#include <fstream>

#include <nlohmann/json.hpp>

#include "eskf/SceneData.hpp"
#include "eskf/Eskf.hpp"
#include "eskf/GpsGeneration.hpp"
#include "eskf/Startup.hpp"

namespace fs = std::filesystem;
using json = nlohmann::json;

namespace
{

    class TempDir
    {
    public:
        TempDir()
        {
            static std::uint64_t counter = 0;
            const auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
            path_ = fs::temp_directory_path() /
                    ("eskf-scene-data-" + std::to_string(stamp) + "-" + std::to_string(counter++));
            fs::create_directories(path_);
        }

        ~TempDir()
        {
            std::error_code ec;
            fs::remove_all(path_, ec);
        }

        const fs::path &path() const
        {
            return path_;
        }

    private:
        fs::path path_;
    };

    void write_json_file(const fs::path &path, const json &data)
    {
        std::ofstream out(path);
        ASSERT_TRUE(out.is_open());
        out << data.dump();
    }

    json make_pose_entry(std::int64_t utime, double x, double y)
    {
        return json{
            {"utime", utime},
            {"pos", {x, y, 0.0}},
            {"orientation", {1.0, 0.0, 0.0, 0.0}},
            {"vel", {1.0, 0.0, 0.0}},
        };
    }

    json make_imu_entry(std::int64_t utime)
    {
        return json{
            {"utime", utime},
            {"linear_accel", {0.0, 0.0, 9.81}},
            {"rotation_rate", {0.0, 0.0, 0.0}},
            {"q", {1.0, 0.0, 0.0, 0.0}},
        };
    }

} // namespace

TEST(EskfIntegration, SceneDemoRunsAndIsNotCatastrophicallyWorseThanRawGps)
{
    const auto pose_path = eskf::resolve_repo_path("scenarios/scene_pose.json");
    const auto imu_path = eskf::resolve_repo_path("scenarios/scene_ms_imu.json");

    const eskf::SceneData scene = eskf::load_scene_data(pose_path, imu_path);
    const std::vector<eskf::ImuSample> &imu_vec = scene.imu_samples;
    const eskf::PoseTruthMap &pose_truth_map = scene.pose_truth;
    const std::vector<eskf::GpsSample> gps_vec = eskf::generate_gps_samples_from_pose(scene.pose_json);

    ASSERT_FALSE(imu_vec.empty());
    ASSERT_GE(gps_vec.size(), 2U);

    const auto startup =
        eskf::compute_startup_initialization(imu_vec, gps_vec);
    ASSERT_TRUE(startup.has_value());

    eskf::Eskf filter;
    const std::size_t imu0_idx = startup->handoff_imu_index;
    std::size_t gps_idx = startup->next_gps_index;
    filter.initialize_from_estimate(
        startup->position_xy,
        startup->velocity_xy,
        startup->yaw_rad,
        imu_vec[imu0_idx]);

    std::size_t n_updates = 0;
    double sum_sq_gps = 0.0;
    double sum_sq_eskf = 0.0;

    for (std::size_t i = imu0_idx + 1; i < imu_vec.size(); ++i)
    {
        const eskf::ImuSample &imu_k = imu_vec[i];
        filter.predict(imu_k);

        while (gps_idx < gps_vec.size() && gps_vec[gps_idx].utime <= imu_k.utime)
        {
            const eskf::GpsSample &gps_k = gps_vec[gps_idx];
            const auto truth_it = pose_truth_map.find(gps_k.utime);
            ASSERT_NE(truth_it, pose_truth_map.end()) << "GPS utime missing in pose truth map: " << gps_k.utime;
            const Eigen::Vector2d &truth_xy = truth_it->second;

            const eskf::UpdateDebug dbg = filter.update_gps(gps_k);
            const eskf::NominalState &st = filter.state();
            const auto &P = filter.covariance();

            ASSERT_TRUE(st.p_G.array().isFinite().all());
            ASSERT_TRUE(st.v_G.array().isFinite().all());
            ASSERT_TRUE(st.q_GI.coeffs().array().isFinite().all());
            ASSERT_NEAR(st.q_GI.norm(), 1.0, 1e-8);

            ASSERT_TRUE(P.array().isFinite().all());
            ASSERT_LE((P - P.transpose()).norm(), 1e-8);

            ASSERT_TRUE(dbg.innovation_xy.array().isFinite().all());
            ASSERT_TRUE(std::isfinite(dbg.nis));
            ASSERT_GE(dbg.nis, 0.0);

            const double dx_gps = gps_k.pos.x() - truth_xy.x();
            const double dy_gps = gps_k.pos.y() - truth_xy.y();
            sum_sq_gps += dx_gps * dx_gps + dy_gps * dy_gps;

            const double dx = st.p_G.x() - truth_xy.x();
            const double dy = st.p_G.y() - truth_xy.y();
            sum_sq_eskf += dx * dx + dy * dy;

            ++n_updates;
            ++gps_idx;

            if (gps_idx >= gps_vec.size())
            {
                break;
            }
        }

        if (gps_idx >= gps_vec.size())
        {
            break;
        }
    }

    ASSERT_GT(n_updates, 0U);
    ASSERT_GE(gps_idx, gps_vec.size());

    const double rmse_gps_xy = std::sqrt(sum_sq_gps / static_cast<double>(n_updates));
    const double rmse_eskf_xy = std::sqrt(sum_sq_eskf / static_cast<double>(n_updates));

    EXPECT_LE(rmse_eskf_xy, 2.0 * rmse_gps_xy);
}

TEST(SceneData, DropsSingleFinalPoseEntryAfterLastImu)
{
    TempDir temp_dir;
    const fs::path pose_path = temp_dir.path() / "pose.json";
    const fs::path imu_path = temp_dir.path() / "imu.json";

    write_json_file(
        pose_path,
        json::array({
            make_pose_entry(100000, 0.0, 0.0),
            make_pose_entry(200000, 1.0, 1.0),
            make_pose_entry(300000, 2.0, 2.0),
        }));
    write_json_file(
        imu_path,
        json::array({
            make_imu_entry(100000),
            make_imu_entry(250000),
        }));

    const eskf::SceneData scene = eskf::load_scene_data(pose_path, imu_path);

    ASSERT_TRUE(scene.pose_json.is_array());
    ASSERT_EQ(scene.pose_json.size(), 2U);
    EXPECT_EQ(scene.pose_json.back().at("utime").get<std::int64_t>(), 200000);
    EXPECT_EQ(scene.pose_truth.size(), 2U);
    EXPECT_EQ(scene.pose_truth.count(300000), 0U);
}

TEST(SceneData, KeepsMultiplePoseEntriesAfterLastImu)
{
    TempDir temp_dir;
    const fs::path pose_path = temp_dir.path() / "pose.json";
    const fs::path imu_path = temp_dir.path() / "imu.json";

    write_json_file(
        pose_path,
        json::array({
            make_pose_entry(100000, 0.0, 0.0),
            make_pose_entry(200000, 1.0, 1.0),
            make_pose_entry(300000, 2.0, 2.0),
            make_pose_entry(400000, 3.0, 3.0),
        }));
    write_json_file(
        imu_path,
        json::array({
            make_imu_entry(100000),
            make_imu_entry(250000),
        }));

    const eskf::SceneData scene = eskf::load_scene_data(pose_path, imu_path);

    ASSERT_TRUE(scene.pose_json.is_array());
    ASSERT_EQ(scene.pose_json.size(), 4U);
    EXPECT_EQ(scene.pose_json.back().at("utime").get<std::int64_t>(), 400000);
    EXPECT_EQ(scene.pose_truth.size(), 4U);
    EXPECT_EQ(scene.pose_truth.count(300000), 1U);
    EXPECT_EQ(scene.pose_truth.count(400000), 1U);
}
