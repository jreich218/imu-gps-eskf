#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>

#include "eskf/Eskf.hpp"
#include "eskf/GpsGeneration.hpp"
#include "eskf/SceneData.hpp"
#include "eskf/Startup.hpp"

namespace
{

    constexpr char kLogPath[] = "eskf_sim_log.csv";

} // namespace

int main(int argc, char **argv)
{
    try
    {
        if (argc != 1)
        {
            throw std::runtime_error("Run eskf_sim with no arguments.");
        }

        const auto scenarios_dir = eskf::resolve_repo_path("scenarios");
        const eskf::SceneInputs inputs = eskf::select_scene_inputs(scenarios_dir);

        std::cout << "Using " << inputs.label << "\n";

        const eskf::SceneData scene = eskf::load_scene_data(inputs.pose_path, inputs.imu_path);
        const std::vector<eskf::ImuSample> &imu_samples = scene.imu_samples;
        const eskf::PoseTruthMap &pose_truth = scene.pose_truth;
        const std::vector<eskf::GpsSample> gps_samples =
            eskf::generate_gps_samples_from_pose(scene.pose_json);

        if (imu_samples.empty())
        {
            throw std::runtime_error("Need at least one IMU sample.");
        }

        if (gps_samples.size() < 2)
        {
            throw std::runtime_error("Need at least two GPS samples.");
        }

        const auto startup =
            eskf::compute_startup_initialization(imu_samples, gps_samples);
        if (!startup)
        {
            throw std::runtime_error("Could not compute startup initialization.");
        }

        eskf::Eskf filter;
        const std::size_t imu_start = startup->handoff_imu_index;
        std::size_t gps_index = startup->next_gps_index;
        filter.initialize_from_estimate(
            startup->position_xy,
            startup->velocity_xy,
            startup->yaw_rad,
            imu_samples[imu_start]);

        std::ofstream out(kLogPath);
        if (!out)
        {
            throw std::runtime_error("Could not open eskf_sim_log.csv for writing.");
        }

        out << "utime,est_x,est_y,est_z,gps_x,gps_y,true_x,true_y,innov_x,innov_y,nis,err_x,err_y,err_norm\n";
        out << std::setprecision(17);

        std::size_t updates = 0;
        double gps_error_sum = 0.0;
        double eskf_error_sum = 0.0;

        for (std::size_t i = imu_start + 1; i < imu_samples.size() && gps_index < gps_samples.size(); ++i)
        {
            filter.predict(imu_samples[i]);

            while (gps_index < gps_samples.size() && gps_samples[gps_index].utime <= imu_samples[i].utime)
            {
                const eskf::GpsSample &gps = gps_samples[gps_index];
                const auto truth_it = pose_truth.find(gps.utime);
                if (truth_it == pose_truth.end())
                {
                    throw std::runtime_error("Missing pose truth for GPS timestamp " + std::to_string(gps.utime));
                }

                const Eigen::Vector2d &truth_xy = truth_it->second;
                const eskf::UpdateDebug debug = filter.update_gps(gps);
                const eskf::NominalState &state = filter.state();

                const double gps_dx = gps.pos.x() - truth_xy.x();
                const double gps_dy = gps.pos.y() - truth_xy.y();
                gps_error_sum += gps_dx * gps_dx + gps_dy * gps_dy;

                const double eskf_dx = state.p_G.x() - truth_xy.x();
                const double eskf_dy = state.p_G.y() - truth_xy.y();
                const double err_norm = std::sqrt(eskf_dx * eskf_dx + eskf_dy * eskf_dy);
                eskf_error_sum += eskf_dx * eskf_dx + eskf_dy * eskf_dy;

                out << gps.utime << ","
                    << state.p_G.x() << "," << state.p_G.y() << "," << state.p_G.z() << ","
                    << gps.pos.x() << "," << gps.pos.y() << ","
                    << truth_xy.x() << "," << truth_xy.y() << ","
                    << debug.innovation_xy.x() << "," << debug.innovation_xy.y() << ","
                    << debug.nis << ","
                    << eskf_dx << "," << eskf_dy << "," << err_norm << "\n";

                ++updates;
                ++gps_index;
            }
        }

        if (updates == 0)
        {
            throw std::runtime_error("No GPS updates were processed.");
        }

        if (gps_index != gps_samples.size())
        {
            throw std::runtime_error("Ran out of IMU samples before the last GPS update.");
        }

        const double gps_rmse = std::sqrt(gps_error_sum / static_cast<double>(updates));
        const double eskf_rmse = std::sqrt(eskf_error_sum / static_cast<double>(updates));

        std::cout << "GPS updates: " << updates << "\n";
        std::cout << "RMSE raw GPS (xy): " << gps_rmse << " m\n";
        std::cout << "RMSE ESKF (xy): " << eskf_rmse << " m\n";
        std::cout << "Wrote log: " << kLogPath << "\n";
        return 0;
    }
    catch (const std::exception &e)
    {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    }
}
