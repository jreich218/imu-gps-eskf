#include "eskf/SceneData.hpp"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <optional>
#include <stdexcept>
#include <vector>

namespace fs = std::filesystem;

namespace eskf
{

    namespace
    {

        constexpr char kBundledPoseName[] = "scene_pose.json";
        constexpr char kBundledImuName[] = "scene_ms_imu.json";
        constexpr char kPoseSuffix[] = "_pose.json";
        constexpr char kImuSuffix[] = "_ms_imu.json";

        bool ends_with(const std::string &value, const std::string &suffix)
        {
            return value.size() >= suffix.size() &&
                   value.compare(value.size() - suffix.size(), suffix.size(), suffix) == 0;
        }

        std::optional<std::string> scene_number_from_name(const std::string &name, const std::string &suffix)
        {
            constexpr char kPrefix[] = "scene-";
            constexpr std::size_t kPrefixLen = sizeof(kPrefix) - 1;

            if (name.rfind(kPrefix, 0) != 0 || !ends_with(name, suffix))
            {
                return std::nullopt;
            }

            const std::size_t digits_len = name.size() - kPrefixLen - suffix.size();
            if (digits_len != 4)
            {
                return std::nullopt;
            }

            const std::string digits = name.substr(kPrefixLen, digits_len);
            const bool all_digits = std::all_of(digits.begin(), digits.end(), [](unsigned char c)
                                                { return std::isdigit(c) != 0; });
            if (!all_digits)
            {
                return std::nullopt;
            }

            return digits;
        }

        nlohmann::json load_json_file(const fs::path &path)
        {
            std::ifstream in(path);
            if (!in)
            {
                throw std::runtime_error("Could not open " + path.string());
            }

            nlohmann::json data;
            in >> data;
            return data;
        }

        std::vector<ImuSample> parse_imu_samples(const nlohmann::json &data)
        {
            if (!data.is_array())
            {
                throw std::runtime_error("IMU JSON root must be an array.");
            }

            std::vector<ImuSample> samples;
            samples.reserve(data.size());

            for (const auto &entry : data)
            {
                ImuSample sample;
                sample.utime = entry.at("utime").get<std::int64_t>();

                const auto &linear_accel = entry.at("linear_accel");
                sample.linear_accel = Eigen::Vector3d(
                    linear_accel.at(0).get<double>(),
                    linear_accel.at(1).get<double>(),
                    linear_accel.at(2).get<double>());

                const auto &rotation_rate = entry.at("rotation_rate");
                sample.rotation_rate = Eigen::Vector3d(
                    rotation_rate.at(0).get<double>(),
                    rotation_rate.at(1).get<double>(),
                    rotation_rate.at(2).get<double>());

                const auto &q = entry.at("q");
                sample.q_AI = Eigen::Quaterniond(
                    q.at(0).get<double>(),
                    q.at(1).get<double>(),
                    q.at(2).get<double>(),
                    q.at(3).get<double>());

                samples.push_back(sample);
            }

            std::sort(samples.begin(), samples.end(), [](const ImuSample &a, const ImuSample &b)
                      { return a.utime < b.utime; });

            return samples;
        }

        PoseTruthMap parse_pose_truth_map(const nlohmann::json &data)
        {
            if (!data.is_array())
            {
                throw std::runtime_error("Pose JSON root must be an array.");
            }

            PoseTruthMap truth_by_utime;
            truth_by_utime.reserve(data.size());

            for (const auto &entry : data)
            {
                const std::int64_t utime = entry.at("utime").get<std::int64_t>();
                const auto &pos = entry.at("pos");
                if (!pos.is_array() || pos.size() < 2)
                {
                    throw std::runtime_error("Each pose entry needs pos[0] and pos[1].");
                }

                const auto [_, inserted] = truth_by_utime.emplace(
                    utime,
                    Eigen::Vector2d(pos.at(0).get<double>(), pos.at(1).get<double>()));
                if (!inserted)
                {
                    throw std::runtime_error("Duplicate pose timestamp: " + std::to_string(utime));
                }
            }

            return truth_by_utime;
        }

        void drop_single_final_pose_after_last_imu(
            nlohmann::json &pose_json,
            const std::vector<ImuSample> &imu_samples)
        {
            if (imu_samples.empty() || !pose_json.is_array() || pose_json.empty())
            {
                return;
            }

            const std::int64_t imu_last_utime = imu_samples.back().utime;
            std::size_t num_pose_entries_after_last_imu = 0;
            for (const auto &entry : pose_json)
            {
                if (entry.at("utime").get<std::int64_t>() > imu_last_utime)
                {
                    ++num_pose_entries_after_last_imu;
                }
            }

            const std::int64_t pose_last_utime =
                pose_json.back().at("utime").get<std::int64_t>();
            if (num_pose_entries_after_last_imu == 1 && pose_last_utime > imu_last_utime)
            {
                pose_json.erase(pose_json.end() - 1);
            }
        }

    } // namespace

    fs::path resolve_repo_path(const fs::path &relative_path)
    {
        const std::vector<fs::path> candidates = {
            relative_path,
            fs::path("..") / relative_path,
            fs::path("../..") / relative_path,
            fs::path("../../..") / relative_path,
        };

        for (const auto &candidate : candidates)
        {
            if (fs::exists(candidate))
            {
                return fs::canonical(candidate);
            }
        }

        throw std::runtime_error("Could not find " + relative_path.string() + ".");
    }

    SceneInputs select_scene_inputs(const fs::path &scenarios_dir)
    {
        const fs::path bundled_pose = scenarios_dir / kBundledPoseName;
        const fs::path bundled_imu = scenarios_dir / kBundledImuName;
        const bool have_bundled_pose = fs::is_regular_file(bundled_pose);
        const bool have_bundled_imu = fs::is_regular_file(bundled_imu);

        std::vector<SceneInputs> nuscenes_pairs;
        std::unordered_map<std::string, fs::path> pose_by_scene;
        std::unordered_map<std::string, fs::path> imu_by_scene;

        for (const auto &entry : fs::directory_iterator(scenarios_dir))
        {
            if (!entry.is_regular_file())
            {
                continue;
            }

            const std::string name = entry.path().filename().string();
            if (const auto scene = scene_number_from_name(name, kPoseSuffix))
            {
                pose_by_scene[*scene] = entry.path();
                continue;
            }

            if (const auto scene = scene_number_from_name(name, kImuSuffix))
            {
                imu_by_scene[*scene] = entry.path();
            }
        }

        if (have_bundled_pose != have_bundled_imu)
        {
            throw std::runtime_error("Keep both bundled files together: scene_pose.json and scene_ms_imu.json.");
        }

        for (const auto &[scene, pose_path] : pose_by_scene)
        {
            const auto imu_it = imu_by_scene.find(scene);
            if (imu_it != imu_by_scene.end())
            {
                nuscenes_pairs.push_back({"nuScenes scene-" + scene, pose_path, imu_it->second});
            }
        }

        if (!pose_by_scene.empty() || !imu_by_scene.empty())
        {
            if (nuscenes_pairs.size() != 1 || pose_by_scene.size() != 1 || imu_by_scene.size() != 1)
            {
                throw std::runtime_error(
                    "Keep exactly one matching pair named scene-XXXX_pose.json and scene-XXXX_ms_imu.json.");
            }

            return nuscenes_pairs.front();
        }

        if (have_bundled_pose && have_bundled_imu)
        {
            return {"bundled scene", bundled_pose, bundled_imu};
        }

        throw std::runtime_error(
            "No input pair found. Keep the bundled pair, or add exactly one matching nuScenes pair.");
    }

    SceneData load_scene_data(const fs::path &pose_path, const fs::path &imu_path)
    {
        SceneData scene;
        scene.pose_json = load_json_file(pose_path);
        scene.imu_samples = parse_imu_samples(load_json_file(imu_path));
        drop_single_final_pose_after_last_imu(scene.pose_json, scene.imu_samples);
        scene.pose_truth = parse_pose_truth_map(scene.pose_json);
        return scene;
    }

} // namespace eskf
