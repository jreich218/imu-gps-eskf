#include "eskf/Eskf.hpp"
#include "eskf/GpsGeneration.hpp"

#include <algorithm>
#include <cmath>
#include <sstream>
#include <stdexcept>

namespace eskf
{

    namespace
    {
        constexpr double kG = 9.8;
        constexpr double kSecPerUsec = 1e-6;
        constexpr double kPi = 3.14159265358979323846;

        constexpr double kSigmaA = 0.5;
        constexpr double kSigmaG = 0.05;

        constexpr double kCovDiagEps = 1e-12;
        constexpr double kCovDiagNegTol = 1e-9;

    } // namespace

    Eskf::Eskf()
    {
    }

    Eigen::Matrix3d Eskf::skew(const Eigen::Vector3d &v)
    {
        Eigen::Matrix3d S;
        S << 0.0, -v.z(), v.y(),
            v.z(), 0.0, -v.x(),
            -v.y(), v.x(), 0.0;
        return S;
    }

    Eigen::Quaterniond Eskf::quat_from_yaw(double yaw_rad)
    {
        const double half = 0.5 * yaw_rad;
        return Eigen::Quaterniond(std::cos(half), 0.0, 0.0, std::sin(half));
    }

    Eigen::Quaterniond Eskf::delta_quat_from_rotvec(const Eigen::Vector3d &dtheta)
    {
        const double angle = dtheta.norm();
        if (angle < 1e-12)
        {
            Eigen::Quaterniond dq(1.0, 0.5 * dtheta.x(), 0.5 * dtheta.y(), 0.5 * dtheta.z());
            return dq.normalized();
        }

        const Eigen::Vector3d axis = dtheta / angle;
        const double half = 0.5 * angle;
        const double s = std::sin(half);
        Eigen::Quaterniond dq(std::cos(half), axis.x() * s, axis.y() * s, axis.z() * s);
        return dq;
    }

    void Eskf::symmetrize_and_clamp(Covariance &P)
    {
        P = 0.5 * (P + P.transpose());

        for (int i = 0; i < P.rows(); ++i)
        {
            const double d = P(i, i);
            if (d < 0.0)
            {
                if (d >= -kCovDiagNegTol)
                {
                    P(i, i) = kCovDiagEps;
                }
                else
                {
                    std::ostringstream oss;
                    oss << "Eskf: covariance diagonal became significantly negative at i=" << i
                        << " (value=" << d << ")";
                    throw std::runtime_error(oss.str());
                }
            }
        }
    }

    void Eskf::initialize_from_estimate(
        const Eigen::Vector2d &position_xy,
        const Eigen::Vector2d &velocity_xy,
        double yaw_rad,
        const ImuSample &imu_ref)
    {
        state_.p_G = Eigen::Vector3d(position_xy.x(), position_xy.y(), 0.0);
        state_.v_G = Eigen::Vector3d(velocity_xy.x(), velocity_xy.y(), 0.0);

        const Eigen::Quaterniond q_AI = imu_ref.q_AI.normalized();
        const Eigen::Vector3d f_A = q_AI * Eigen::Vector3d::UnitX();
        const double yaw_A = std::atan2(f_A.y(), f_A.x());
        const double yaw_corr = yaw_rad - yaw_A;

        const Eigen::Quaterniond q_GA = quat_from_yaw(yaw_corr);
        state_.q_GI = (q_GA * q_AI).normalized();

        P_.setZero();
        P_(0, 0) = 4.0;
        P_(1, 1) = 4.0;
        P_(2, 2) = 0.01;

        P_(3, 3) = 4.0;
        P_(4, 4) = 4.0;
        P_(5, 5) = 0.01;

        P_(6, 6) = std::pow(2.0 * kPi / 180.0, 2);
        P_(7, 7) = std::pow(2.0 * kPi / 180.0, 2);
        P_(8, 8) = std::pow(10.0 * kPi / 180.0, 2);

        last_imu_utime_ = imu_ref.utime;
        initialized_ = true;
    }

    void Eskf::predict(const ImuSample &imu_k)
    {
        if (!initialized_)
        {
            throw std::runtime_error("Eskf::predict: filter is not initialized");
        }

        const std::int64_t dt_us = imu_k.utime - last_imu_utime_;
        const double dt = static_cast<double>(dt_us) * kSecPerUsec;
        if (!(dt > 0.0))
        {
            throw std::runtime_error("Eskf::predict: dt must be > 0");
        }
        last_imu_utime_ = imu_k.utime;

        const Eigen::Vector3d omega_I = imu_k.rotation_rate;
        const Eigen::Quaterniond dq = delta_quat_from_rotvec(omega_I * dt);
        state_.q_GI = (state_.q_GI * dq).normalized();

        const Eigen::Vector3d g_A(0.0, 0.0, -kG);
        const Eigen::Quaterniond q_AI = imu_k.q_AI.normalized();
        const Eigen::Vector3d g_I = q_AI.conjugate() * g_A;
        const Eigen::Vector3d a_I = imu_k.linear_accel + g_I;

        const Eigen::Vector3d a_G = state_.q_GI * a_I;
        state_.p_G += state_.v_G * dt + 0.5 * a_G * dt * dt;
        state_.v_G += a_G * dt;

        const Eigen::Matrix3d R_GI = state_.q_GI.toRotationMatrix();
        const Eigen::Matrix3d a_skew = skew(a_I);
        const Eigen::Matrix3d w_skew = skew(omega_I);

        Covariance F = Covariance::Identity();
        F.block<3, 3>(0, 3) = Eigen::Matrix3d::Identity() * dt;
        // a_G = R_GI * a_I, so the attitude terms use a_I.
        F.block<3, 3>(0, 6) = -0.5 * R_GI * a_skew * (dt * dt);
        F.block<3, 3>(3, 6) = -R_GI * a_skew * dt;
        F.block<3, 3>(6, 6) = Eigen::Matrix3d::Identity() - w_skew * dt;

        Eigen::Matrix<double, 9, 6> G = Eigen::Matrix<double, 9, 6>::Zero();
        G.block<3, 3>(0, 0) = 0.5 * R_GI * (dt * dt);
        G.block<3, 3>(3, 0) = R_GI * dt;
        G.block<3, 3>(6, 3) = Eigen::Matrix3d::Identity() * dt;

        Eigen::Matrix<double, 6, 6> Qc = Eigen::Matrix<double, 6, 6>::Zero();
        Qc.block<3, 3>(0, 0) = (kSigmaA * kSigmaA) * Eigen::Matrix3d::Identity();
        Qc.block<3, 3>(3, 3) = (kSigmaG * kSigmaG) * Eigen::Matrix3d::Identity();

        const Covariance Q = G * Qc * G.transpose();

        P_ = F * P_ * F.transpose() + Q;
        symmetrize_and_clamp(P_);
    }

    UpdateDebug Eskf::update_gps(const GpsSample &gps_k)
    {
        if (!initialized_)
        {
            throw std::runtime_error("Eskf::update_gps: filter is not initialized");
        }

        // Measurement z = [x, y]^T
        const Eigen::Vector2d z = gps_k.pos;

        // h(x) = [p_G.x, p_G.y]^T
        Eigen::Vector2d h;
        h << state_.p_G.x(), state_.p_G.y();

        const Eigen::Vector2d innov = z - h;

        // Jacobian H (2x9): selects x,y from δp.
        Eigen::Matrix<double, 2, 9> H = Eigen::Matrix<double, 2, 9>::Zero();
        H(0, 0) = 1.0;
        H(1, 1) = 1.0;

        const Eigen::Matrix2d R =
            (kDefaultGpsSigmaXY * kDefaultGpsSigmaXY) * Eigen::Matrix2d::Identity();

        const Eigen::Matrix2d S = H * P_ * H.transpose() + R;

        Eigen::LDLT<Eigen::Matrix2d> ldlt(S);
        if (ldlt.info() != Eigen::Success)
        {
            throw std::runtime_error("Eskf::update_gps: failed to factorize S");
        }

        const Eigen::Matrix<double, 9, 2> PHt = P_ * H.transpose();
        const Eigen::Matrix2d S_inv = ldlt.solve(Eigen::Matrix2d::Identity());
        const Eigen::Matrix<double, 9, 2> K = PHt * S_inv;

        const Eigen::Matrix<double, 9, 1> dx = K * innov;

        const Eigen::Vector3d d_p = dx.segment<3>(0);
        const Eigen::Vector3d d_v = dx.segment<3>(3);
        const Eigen::Vector3d d_theta = dx.segment<3>(6);

        state_.p_G += d_p;
        state_.v_G += d_v;
        state_.q_GI = (state_.q_GI * delta_quat_from_rotvec(d_theta)).normalized();

        const Covariance I = Covariance::Identity();
        const Covariance I_KH = I - K * H;
        P_ = I_KH * P_ * I_KH.transpose() + K * R * K.transpose();
        symmetrize_and_clamp(P_);

        const double nis = innov.dot(ldlt.solve(innov));

        UpdateDebug dbg;
        dbg.innovation_xy = innov;
        dbg.nis = nis;
        return dbg;
    }

    const NominalState &Eskf::state() const
    {
        return state_;
    }

    const Eskf::Covariance &Eskf::covariance() const
    {
        return P_;
    }

} // namespace eskf
