#include "eskf/Startup.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

#include <Eigen/Dense>

namespace eskf
{

    namespace
    {

        constexpr double kSecPerUsec = 1e-6;
        constexpr double kPi = 3.14159265358979323846;
        constexpr std::size_t kMinFitPointCount = 3;
        constexpr std::size_t kStabilityWindow = 3;
        constexpr double kTangentStabilityTolRad = 10.0 * kPi / 180.0;
        constexpr double kMinEndpointSpeed = 1e-6;
        constexpr std::size_t kRelaxedProjectedSeparationPointCount = 80;
        constexpr double kEarlyMinProjectedSeparationM = 10.0;
        constexpr double kLateMinProjectedSeparationM = 7.0;
        constexpr double kMaxLineLikeSecondToFirstVarianceRatio = 0.1;
        constexpr double kRecentSpeedWindowSec = 1.0;
        constexpr int kPathLengthQuadratureSteps = 32;

        struct QuadraticStartupPath
        {
            Eigen::Vector3d coeff_x = Eigen::Vector3d::Zero();
            Eigen::Vector3d coeff_y = Eigen::Vector3d::Zero();
            std::int64_t end_utime = 0;
        };

        struct PathHeadingSample
        {
            std::size_t gps_end_idx = 0;
            std::int64_t end_utime = 0;
            double yaw_rad = 0.0;
        };

        struct PrincipalDirectionSummary
        {
            Eigen::Vector2d axis = Eigen::Vector2d::UnitX();
            double first_variance = 0.0;
            double second_variance = 0.0;
            double projected_start_to_end_m = 0.0;
        };

        double wrap_angle(double angle_rad)
        {
            return std::atan2(std::sin(angle_rad), std::cos(angle_rad));
        }

        double angle_diff(double a_rad, double b_rad)
        {
            return wrap_angle(a_rad - b_rad);
        }

        std::optional<std::size_t> find_first_usable_gps_sample(
            const std::vector<ImuSample> &imu_samples,
            const std::vector<GpsSample> &gps_samples)
        {
            if (imu_samples.empty())
            {
                throw std::runtime_error("Startup initialization needs at least one IMU sample.");
            }

            std::size_t gps_index = 0;
            while (gps_index < gps_samples.size() &&
                   gps_samples[gps_index].utime < imu_samples.front().utime)
            {
                ++gps_index;
            }

            if (gps_index >= gps_samples.size())
            {
                return std::nullopt;
            }

            return gps_index;
        }

        bool has_minimum_points_for_fit(std::size_t gps_point_count_from_r1)
        {
            return gps_point_count_from_r1 >= kMinFitPointCount;
        }

        QuadraticStartupPath fit_quadratic_startup_path(
            const std::vector<GpsSample> &gps_samples,
            std::size_t first_idx,
            std::size_t last_idx)
        {
            if (last_idx < first_idx + kMinFitPointCount - 1)
            {
                throw std::runtime_error("Startup path fit needs at least three GPS points.");
            }

            const std::size_t point_count = last_idx - first_idx + 1;
            Eigen::MatrixXd A(point_count, 3);
            Eigen::VectorXd x(point_count);
            Eigen::VectorXd y(point_count);

            const std::int64_t end_utime = gps_samples[last_idx].utime;
            for (std::size_t row = 0; row < point_count; ++row)
            {
                const std::size_t sample_idx = first_idx + row;
                const double tau_s =
                    static_cast<double>(gps_samples[sample_idx].utime - end_utime) * kSecPerUsec;
                A(static_cast<Eigen::Index>(row), 0) = 1.0;
                A(static_cast<Eigen::Index>(row), 1) = tau_s;
                A(static_cast<Eigen::Index>(row), 2) = tau_s * tau_s;
                x(static_cast<Eigen::Index>(row)) = gps_samples[sample_idx].pos.x();
                y(static_cast<Eigen::Index>(row)) = gps_samples[sample_idx].pos.y();
            }

            Eigen::ColPivHouseholderQR<Eigen::MatrixXd> qr(A);
            if (qr.rank() < 3)
            {
                throw std::runtime_error("Startup path fit needs distinct GPS timestamps.");
            }

            QuadraticStartupPath path;
            path.coeff_x = qr.solve(x);
            path.coeff_y = qr.solve(y);
            path.end_utime = end_utime;
            return path;
        }

        Eigen::Vector2d position_at(const QuadraticStartupPath &path, double tau_s)
        {
            return Eigen::Vector2d(
                path.coeff_x.x() + path.coeff_x.y() * tau_s + path.coeff_x.z() * tau_s * tau_s,
                path.coeff_y.x() + path.coeff_y.y() * tau_s + path.coeff_y.z() * tau_s * tau_s);
        }

        Eigen::Vector2d velocity_at(const QuadraticStartupPath &path, double tau_s)
        {
            return Eigen::Vector2d(
                path.coeff_x.y() + 2.0 * path.coeff_x.z() * tau_s,
                path.coeff_y.y() + 2.0 * path.coeff_y.z() * tau_s);
        }

        double path_length_between(const QuadraticStartupPath &path, double tau_start_s, double tau_end_s)
        {
            if (tau_end_s < tau_start_s)
            {
                throw std::runtime_error("Startup path length interval must be nondecreasing.");
            }

            if (tau_end_s == tau_start_s)
            {
                return 0.0;
            }

            const double h =
                (tau_end_s - tau_start_s) / static_cast<double>(kPathLengthQuadratureSteps);
            double weighted_sum = 0.0;
            for (int step = 0; step <= kPathLengthQuadratureSteps; ++step)
            {
                const double tau_s = tau_start_s + static_cast<double>(step) * h;
                const double speed = velocity_at(path, tau_s).norm();
                if (step == 0 || step == kPathLengthQuadratureSteps)
                {
                    weighted_sum += speed;
                }
                else if (step % 2 == 0)
                {
                    weighted_sum += 2.0 * speed;
                }
                else
                {
                    weighted_sum += 4.0 * speed;
                }
            }

            return weighted_sum * h / 3.0;
        }

        double delta_yaw_between(
            const std::vector<ImuSample> &imu_samples,
            std::int64_t start_utime,
            std::int64_t end_utime)
        {
            if (end_utime < start_utime)
            {
                throw std::runtime_error("Startup IMU interval must be nondecreasing.");
            }

            double delta_yaw = 0.0;
            for (std::size_t idx = 1; idx < imu_samples.size(); ++idx)
            {
                const std::int64_t seg_start = imu_samples[idx - 1].utime;
                const std::int64_t seg_end = imu_samples[idx].utime;
                const std::int64_t overlap_start = std::max(seg_start, start_utime);
                const std::int64_t overlap_end = std::min(seg_end, end_utime);
                if (overlap_end <= overlap_start)
                {
                    continue;
                }

                const double dt_s =
                    static_cast<double>(overlap_end - overlap_start) * kSecPerUsec;
                const Eigen::Quaterniond q_AI = imu_samples[idx].q_AI.normalized();
                const Eigen::Vector3d omega_A = q_AI * imu_samples[idx].rotation_rate;
                delta_yaw += omega_A.z() * dt_s;
            }

            return delta_yaw;
        }

        std::optional<double> stability_max_error_rad(
            const std::vector<PathHeadingSample> &candidates)
        {
            if (candidates.size() < kStabilityWindow)
            {
                return std::nullopt;
            }

            const double latest_yaw = candidates.back().yaw_rad;
            const std::size_t first_idx = candidates.size() - kStabilityWindow;
            double max_error = 0.0;
            for (std::size_t idx = first_idx; idx < candidates.size(); ++idx)
            {
                max_error = std::max(
                    max_error,
                    std::abs(angle_diff(candidates[idx].yaw_rad, latest_yaw)));
            }

            return max_error;
        }

        PrincipalDirectionSummary summarize_first_principal_component(
            const std::vector<GpsSample> &gps_samples,
            std::size_t first_idx,
            std::size_t last_idx)
        {
            const std::size_t point_count = last_idx - first_idx + 1;
            if (point_count < 2)
            {
                throw std::runtime_error("Startup PCA needs at least two GPS points.");
            }

            Eigen::Vector2d mean = Eigen::Vector2d::Zero();
            for (std::size_t idx = first_idx; idx <= last_idx; ++idx)
            {
                mean += gps_samples[idx].pos;
            }
            mean /= static_cast<double>(point_count);

            Eigen::Matrix2d covariance = Eigen::Matrix2d::Zero();
            for (std::size_t idx = first_idx; idx <= last_idx; ++idx)
            {
                const Eigen::Vector2d centered = gps_samples[idx].pos - mean;
                covariance += centered * centered.transpose();
            }
            covariance /= static_cast<double>(point_count);

            Eigen::SelfAdjointEigenSolver<Eigen::Matrix2d> solver(covariance);
            if (solver.info() != Eigen::Success)
            {
                throw std::runtime_error("Startup PCA failed.");
            }

            PrincipalDirectionSummary summary;
            summary.axis = solver.eigenvectors().col(1).normalized();
            summary.first_variance = solver.eigenvalues()(1);
            summary.second_variance = solver.eigenvalues()(0);

            const Eigen::Vector2d start_to_end =
                gps_samples[last_idx].pos - gps_samples[first_idx].pos;
            if (summary.axis.dot(start_to_end) < 0.0)
            {
                summary.axis = -summary.axis;
            }

            summary.projected_start_to_end_m =
                std::abs(summary.axis.dot(start_to_end));
            return summary;
        }

        double required_projected_separation_m(std::size_t gps_point_count_from_r1)
        {
            return gps_point_count_from_r1 >= kRelaxedProjectedSeparationPointCount
                       ? kLateMinProjectedSeparationM
                       : kEarlyMinProjectedSeparationM;
        }

        double principal_component_yaw_rad(const PrincipalDirectionSummary &pca)
        {
            return std::atan2(pca.axis.y(), pca.axis.x());
        }

        bool principal_component_is_line_like(const PrincipalDirectionSummary &pca)
        {
            if (!(pca.first_variance > 0.0))
            {
                return true;
            }

            return (pca.second_variance / pca.first_variance) <=
                   kMaxLineLikeSecondToFirstVarianceRatio;
        }

        double global_yaw_from_principal_component_and_curvature(
            const PrincipalDirectionSummary &pca,
            const std::vector<ImuSample> &imu_samples,
            std::int64_t start_utime,
            std::int64_t end_utime)
        {
            const double principal_component_yaw = principal_component_yaw_rad(pca);
            if (principal_component_is_line_like(pca))
            {
                return principal_component_yaw;
            }

            const double total_imu_delta_yaw =
                delta_yaw_between(imu_samples, start_utime, end_utime);
            return wrap_angle(principal_component_yaw + 0.5 * total_imu_delta_yaw);
        }

        double tangent_weight_from_recent_heading_behavior(
            const std::vector<PathHeadingSample> &candidates)
        {
            const auto max_error = stability_max_error_rad(candidates);
            if (!max_error.has_value())
            {
                return 0.0;
            }

            const double normalized_error =
                std::clamp(*max_error / kTangentStabilityTolRad, 0.0, 1.0);
            return 1.0 - normalized_error;
        }

        std::int64_t recent_speed_window_start_utime(
            std::int64_t startup_begin_utime,
            std::int64_t ready_utime)
        {
            const std::int64_t requested_window_usec =
                static_cast<std::int64_t>(kRecentSpeedWindowSec / kSecPerUsec);
            return std::max(startup_begin_utime, ready_utime - requested_window_usec);
        }

        Eigen::Vector2d unit_direction(double yaw_rad)
        {
            return Eigen::Vector2d(std::cos(yaw_rad), std::sin(yaw_rad));
        }

        double blend_yaws(double tangent_yaw_rad, double global_yaw_rad, double tangent_weight)
        {
            const double clamped_tangent_weight = std::clamp(tangent_weight, 0.0, 1.0);
            const double global_weight = 1.0 - clamped_tangent_weight;
            const Eigen::Vector2d blended =
                clamped_tangent_weight * unit_direction(tangent_yaw_rad) +
                global_weight * unit_direction(global_yaw_rad);
            if (blended.squaredNorm() <= 1e-12)
            {
                return clamped_tangent_weight >= 0.5 ? tangent_yaw_rad : global_yaw_rad;
            }

            return std::atan2(blended.y(), blended.x());
        }

        double local_speed_from_recent_fitted_path(
            const QuadraticStartupPath &path,
            std::int64_t recent_start_utime)
        {
            const double recent_start_tau_s =
                static_cast<double>(recent_start_utime - path.end_utime) * kSecPerUsec;
            const double duration_s = -recent_start_tau_s;
            if (!(duration_s > 0.0))
            {
                return velocity_at(path, 0.0).norm();
            }

            const double length_m = path_length_between(path, recent_start_tau_s, 0.0);
            return length_m / duration_s;
        }

        double arc_length_from_chord_and_turn(double chord_m, double abs_turn_rad)
        {
            if (!(chord_m > 0.0))
            {
                return 0.0;
            }

            if (abs_turn_rad < 1e-6)
            {
                return chord_m;
            }

            const double denominator = 2.0 * std::sin(0.5 * abs_turn_rad);
            if (std::abs(denominator) < 1e-9)
            {
                return chord_m;
            }

            return chord_m * abs_turn_rad / denominator;
        }

        double global_speed_from_recent_path(
            const QuadraticStartupPath &path,
            const PrincipalDirectionSummary &pca,
            const std::vector<ImuSample> &imu_samples,
            std::int64_t recent_start_utime,
            double global_yaw_rad)
        {
            const double recent_start_tau_s =
                static_cast<double>(recent_start_utime - path.end_utime) * kSecPerUsec;
            const double duration_s = -recent_start_tau_s;
            if (!(duration_s > 0.0))
            {
                return velocity_at(path, 0.0).norm();
            }

            const Eigen::Vector2d recent_start_xy = position_at(path, recent_start_tau_s);
            const Eigen::Vector2d recent_end_xy = position_at(path, 0.0);
            const Eigen::Vector2d delta_xy = recent_end_xy - recent_start_xy;

            double path_length_m = 0.0;
            if (principal_component_is_line_like(pca))
            {
                path_length_m = std::abs(unit_direction(global_yaw_rad).dot(delta_xy));
            }
            else
            {
                const double recent_abs_turn_rad =
                    std::abs(delta_yaw_between(imu_samples, recent_start_utime, path.end_utime));
                path_length_m =
                    arc_length_from_chord_and_turn(delta_xy.norm(), recent_abs_turn_rad);
            }

            return path_length_m / duration_s;
        }

        double blend_speeds(double local_speed_mps, double global_speed_mps, double tangent_weight)
        {
            const double clamped_tangent_weight = std::clamp(tangent_weight, 0.0, 1.0);
            return clamped_tangent_weight * local_speed_mps +
                   (1.0 - clamped_tangent_weight) * global_speed_mps;
        }

        std::optional<StartupInitialization> carry_state_to_first_imu_at_or_after_time(
            const std::vector<ImuSample> &imu_samples,
            std::int64_t ready_utime,
            const Eigen::Vector2d &ready_position_xy,
            const Eigen::Vector2d &ready_velocity_xy,
            double ready_yaw_rad,
            std::size_t next_gps_index)
        {
            std::size_t handoff_imu_index = 0;
            while (handoff_imu_index < imu_samples.size() &&
                   imu_samples[handoff_imu_index].utime < ready_utime)
            {
                ++handoff_imu_index;
            }
            if (handoff_imu_index >= imu_samples.size())
            {
                return std::nullopt;
            }

            const double dt_gap_s =
                static_cast<double>(imu_samples[handoff_imu_index].utime - ready_utime) *
                kSecPerUsec;
            const double delta_yaw =
                delta_yaw_between(
                    imu_samples,
                    ready_utime,
                    imu_samples[handoff_imu_index].utime);

            StartupInitialization startup;
            startup.position_xy = ready_position_xy + ready_velocity_xy * dt_gap_s;
            startup.velocity_xy = ready_velocity_xy;
            startup.yaw_rad = ready_yaw_rad + delta_yaw;
            startup.handoff_imu_index = handoff_imu_index;
            startup.next_gps_index = next_gps_index;
            return startup;
        }

    } // namespace

    std::optional<StartupInitialization> compute_startup_initialization(
        const std::vector<ImuSample> &imu_samples,
        const std::vector<GpsSample> &gps_samples)
    {
        const auto first_usable_gps_index =
            find_first_usable_gps_sample(imu_samples, gps_samples);
        if (!first_usable_gps_index.has_value())
        {
            return std::nullopt;
        }

        const std::size_t gps_start_idx = *first_usable_gps_index;
        const std::size_t gps_point_count_from_r1 = gps_samples.size() - gps_start_idx;
        if (!has_minimum_points_for_fit(gps_point_count_from_r1))
        {
            return std::nullopt;
        }

        std::vector<PathHeadingSample> candidates;
        for (std::size_t fit_end_idx = gps_start_idx + (kMinFitPointCount - 1);
             fit_end_idx < gps_samples.size();
             ++fit_end_idx)
        {
            const std::size_t gps_points_used = fit_end_idx - gps_start_idx + 1;
            const QuadraticStartupPath path =
                fit_quadratic_startup_path(gps_samples, gps_start_idx, fit_end_idx);
            const Eigen::Vector2d endpoint_velocity = velocity_at(path, 0.0);
            const double endpoint_speed = endpoint_velocity.norm();
            if (!(endpoint_speed > kMinEndpointSpeed))
            {
                continue;
            }

            const double endpoint_yaw =
                std::atan2(endpoint_velocity.y(), endpoint_velocity.x());
            candidates.push_back({fit_end_idx, gps_samples[fit_end_idx].utime, endpoint_yaw});

            const PrincipalDirectionSummary pca =
                summarize_first_principal_component(gps_samples, gps_start_idx, fit_end_idx);
            if (pca.projected_start_to_end_m <
                required_projected_separation_m(gps_points_used))
            {
                continue;
            }
            const double global_yaw_rad =
                global_yaw_from_principal_component_and_curvature(
                    pca,
                    imu_samples,
                    gps_samples[gps_start_idx].utime,
                    gps_samples[fit_end_idx].utime);
            const double tangent_weight =
                tangent_weight_from_recent_heading_behavior(candidates);
            const double blended_yaw_rad =
                blend_yaws(endpoint_yaw, global_yaw_rad, tangent_weight);
            const std::int64_t recent_start_utime =
                recent_speed_window_start_utime(
                    gps_samples[gps_start_idx].utime,
                    gps_samples[fit_end_idx].utime);
            const double local_speed_mps =
                local_speed_from_recent_fitted_path(path, recent_start_utime);
            const double global_speed_mps =
                global_speed_from_recent_path(
                    path,
                    pca,
                    imu_samples,
                    recent_start_utime,
                    global_yaw_rad);
            const double blended_speed_mps =
                blend_speeds(local_speed_mps, global_speed_mps, tangent_weight);
            const Eigen::Vector2d blended_velocity_xy =
                blended_speed_mps * unit_direction(blended_yaw_rad);

            return carry_state_to_first_imu_at_or_after_time(
                imu_samples,
                gps_samples[fit_end_idx].utime,
                position_at(path, 0.0),
                blended_velocity_xy,
                blended_yaw_rad,
                fit_end_idx + 1);
        }

        return std::nullopt;
    }

} // namespace eskf
