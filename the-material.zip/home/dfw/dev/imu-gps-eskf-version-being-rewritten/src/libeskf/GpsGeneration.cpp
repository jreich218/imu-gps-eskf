#include "eskf/GpsGeneration.hpp"

#include <cmath>
#include <random>
#include <sstream>
#include <stdexcept>

namespace eskf
{

    std::vector<GpsSample> generate_gps_samples_from_pose(
        const nlohmann::json &pose_array,
        double gps_hz,
        double sigma_xy,
        unsigned int seed)
    {
        if (!pose_array.is_array())
        {
            throw std::runtime_error("Pose JSON root is not an array");
        }
        if (pose_array.empty())
        {
            throw std::runtime_error("Pose array must contain at least 1 entry");
        }
        if (gps_hz <= 0.0)
        {
            throw std::runtime_error("GPS generation requires gps_hz > 0");
        }
        if (sigma_xy < 0.0)
        {
            throw std::runtime_error("GPS generation requires sigma_xy >= 0");
        }

        constexpr double kPoseEps = 1e-6;
        const long long desired_dt_us = static_cast<long long>(std::llround(1e6 / gps_hz));

        std::mt19937 rng(seed);
        std::normal_distribution<double> standard_normal(0.0, 1.0);

        std::vector<GpsSample> gps;
        gps.reserve(pose_array.size());

        bool first_kept = false;
        long long last_kept_utime = 0;
        bool first_seen_utime = true;
        long long prev_utime = 0;

        for (const auto &pose_entry : pose_array)
        {
            if (!pose_entry.contains("utime") ||
                !pose_entry.contains("pos") ||
                !pose_entry.contains("orientation") ||
                !pose_entry.contains("vel"))
            {
                throw std::runtime_error("Pose entry is missing one of: 'utime', 'pos', 'orientation', 'vel'");
            }

            const long long utime = pose_entry.at("utime").get<long long>();
            if (!first_seen_utime && utime <= prev_utime)
            {
                std::ostringstream oss;
                oss << "Pose utime is not strictly increasing: utime=" << utime
                    << " <= previous utime=" << prev_utime;
                throw std::runtime_error(oss.str());
            }
            first_seen_utime = false;
            prev_utime = utime;

            const auto &pos = pose_entry.at("pos");
            if (!pos.is_array() || pos.size() < 3)
            {
                throw std::runtime_error("Pose entry 'pos' must be an array of length >= 3");
            }

            const double x_true = pos.at(0).get<double>();
            const double y_true = pos.at(1).get<double>();
            const double z_true = pos.at(2).get<double>();
            if (std::abs(z_true) > kPoseEps)
            {
                std::ostringstream oss;
                oss << "Pose invariant violated at utime=" << utime
                    << ": expected pos[2] ~= 0, got " << z_true;
                throw std::runtime_error(oss.str());
            }

            const auto &orientation = pose_entry.at("orientation");
            if (!orientation.is_array() || orientation.size() != 4)
            {
                throw std::runtime_error("Pose entry 'orientation' must be an array of length 4");
            }
            const double ori_x = orientation.at(1).get<double>();
            const double ori_y = orientation.at(2).get<double>();
            if (std::abs(ori_x) > kPoseEps || std::abs(ori_y) > kPoseEps)
            {
                std::ostringstream oss;
                oss << "Pose invariant violated at utime=" << utime
                    << ": expected orientation[1] and [2] ~= 0";
                throw std::runtime_error(oss.str());
            }

            const auto &vel = pose_entry.at("vel");
            if (!vel.is_array() || vel.size() != 3)
            {
                throw std::runtime_error("Pose entry 'vel' must be an array of length 3");
            }
            const double vel_y = vel.at(1).get<double>();
            const double vel_z = vel.at(2).get<double>();
            if (std::abs(vel_y) > kPoseEps || std::abs(vel_z) > kPoseEps)
            {
                std::ostringstream oss;
                oss << "Pose invariant violated at utime=" << utime
                    << ": expected vel[1] and vel[2] ~= 0";
                throw std::runtime_error(oss.str());
            }

            if (!first_kept)
            {
                first_kept = true;
                last_kept_utime = utime;
            }
            else if (utime - last_kept_utime < desired_dt_us)
            {
                continue;
            }
            else
            {
                last_kept_utime = utime;
            }

            const double nx = sigma_xy > 0.0 ? sigma_xy * standard_normal(rng) : 0.0;
            const double ny = sigma_xy > 0.0 ? sigma_xy * standard_normal(rng) : 0.0;

            GpsSample sample;
            sample.utime = utime;
            sample.pos = Eigen::Vector2d(x_true + nx, y_true + ny);
            gps.push_back(sample);
        }

        return gps;
    }

} // namespace eskf
